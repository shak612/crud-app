import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { addUser, getUser } from "../Store/ActionCreators/UserActionCreators";
import { useSelector, useDispatch } from "react-redux";
import { useEffect } from "react";

export default function SignUp() {
  let [data, setData] = useState({
    name: "",
    username: "",
    email: "",
    phone: "",
    password: "",
    cpassword: "",
  });
  let [show, setShow] = useState(false);
  let [msg, setMsg] = useState("");
  let dispatch = useDispatch();
  let navigate = useNavigate();
  let user = useSelector((state) => state.UserStateData);
  function getData(e) {
    let name = e.target.name;
    let value = e.target.value;
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
  }
  function postData(e) {
    e.preventDefault();
    if (data.password === data.cpassword) {
      let filterUser = user.find((item) => item.username === data.username);
      if (filterUser) {
        setShow(true);
        setMsg("User Name is Already Taken!!");
      } else {
        let item = {
          name: data.name,
          username: data.username,
          email: data.email,
          phone: data.phone,
          password: data.password,
          role: "User",
        };
        dispatch(addUser(item));
        navigate("/login");
      }
    } else {
      setShow(true);
      setMsg("Password and Confirm Password Doesn't Matched!!");
    }
  }

  useEffect(() => {
    dispatch(getUser());
  }, []);
  return (
    <>
      <div style={{ width: "100vw" }}>
        <div className="register-box" style={{ width: "40%", margin: "auto" }}>
          <div className="card">
            <div className="card-body register-card-body">
              <p className="login-box-msg">Register a new membership</p>
              {show && (
                <div
                  className="alert alert-danger alert-dismissible fade show text-center"
                  role="alert"
                >
                  <strong>{msg}</strong>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="alert"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
              )}
              <form onSubmit={postData}>
                <div className="input-group mb-3">
                  <input
                    required
                    type="text"
                    className="form-control"
                    name="name"
                    onChange={getData}
                    placeholder="Full name"
                    minLength={3}
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">person</span>
                    </div>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <input
                    required
                    type="text"
                    className="form-control"
                    name="username"
                    onChange={getData}
                    placeholder="User name"
                    minLength={3}
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">person</span>
                    </div>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <input
                    required
                    type="email"
                    className="form-control"
                    name="email"
                    onChange={getData}
                    placeholder="Email"
                    minLength={13}
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">mail</span>
                    </div>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <input
                    required
                    type="text"
                    className="form-control"
                    name="phone"
                    onChange={getData}
                    placeholder="Phone"
                    minLength={10}
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">call</span>
                    </div>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <input
                    required
                    type="password"
                    className="form-control"
                    name="password"
                    onChange={getData}
                    placeholder="Password"
                    minLength={8}
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">lock</span>
                    </div>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <input
                    required
                    type="password"
                    className="form-control"
                    name="cpassword"
                    onChange={getData}
                    placeholder="Confirm password"
                    minLength={8}
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">lock</span>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-6">
                    <div className="icheck-primary">
                      <input
                        type="checkbox"
                        id="agreeTerms"
                        name="terms"
                        value="agree"
                        required
                      />
                      <label htmlFor="agreeTerms">
                        I agree to the <a href="#">terms</a>
                      </label>
                    </div>
                  </div>
                  <div className="col-6">
                    <button type="submit" className="btn btn-primary btn-block">
                      Create
                    </button>
                  </div>
                </div>
              </form>

              <div className="social-auth-links text-center">
                <p>- OR -</p>
                <a href="#" className="btn btn-block btn-primary">
                  <i className="fab fa-facebook mr-2"></i>
                  Sign up using Facebook
                </a>
                <a href="#" className="btn btn-block btn-danger">
                  <i className="fab fa-google-plus mr-2"></i>
                  Sign up using Google+
                </a>
              </div>
              <Link to="/login" className="text-center">
                Already have an account
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

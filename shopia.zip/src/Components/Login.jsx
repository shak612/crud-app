import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { login, getUser } from "../Store/ActionCreators/UserActionCreators";
import { useSelector, useDispatch } from "react-redux";

export default function Login() {
  let [data, setData] = useState({
    username: "",
    password: "",
  });

  let [show, setShow] = useState(false);
  let [msg, setMsg] = useState("");
  let dispatch = useDispatch();
  let navigate = useNavigate();
  let user = useSelector((state) => state.UserStateData);
  function getData(e) {
    let name = e.target.name;
    let value = e.target.value;
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
  }

  function postData(e) {
    e.preventDefault();
    dispatch(login({ username: data.username, password: data.password }));
    if (user.result && user.result === "Done") navigate("/profile");
    else setShow(true);
  }

  useEffect(() => {
    dispatch(getUser());
  }, []);
  return (
    <>
      <div style={{ width: "100vw" }}>
        <div className="login-box" style={{ width: "50%", margin: "auto" }}>
          <div className="card">
            <div className="card-body login-card-body">
              <p className="login-box-msg">Sign in to start your session</p>
              {show && (
                <div
                  className="alert alert-danger alert-dismissible fade show text-center"
                  role="alert"
                >
                  <strong>Invalid User or Password!!</strong>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="alert"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
              )}
              <form onSubmit={postData}>
                <div className="input-group mb-3">
                  <input
                    required
                    type="text"
                    className="form-control"
                    name="username"
                    onChange={getData}
                    placeholder="username"
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">person</span>
                    </div>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <input
                    required
                    type="password"
                    className="form-control"
                    name="password"
                    onChange={getData}
                    placeholder="Password"
                  />
                  <div className="input-group-append">
                    <div className="input-group-text">
                      <span className="material-symbols-outlined">lock</span>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-8">
                    <div className="icheck-primary">
                      <input type="checkbox" id="remember" required />
                      <label htmlFor="remember">Remember Me</label>
                    </div>
                  </div>
                  <div className="col-4">
                    <button type="submit" className="btn btn-primary btn-block">
                      Sign In
                    </button>
                  </div>
                </div>
              </form>

              <div className="social-auth-links text-center mb-3">
                <p>- OR -</p>
                <a href="#" className="btn btn-block btn-primary">
                  <i className="fab fa-facebook mr-2"></i> Sign in using
                  Facebook
                </a>
                <a href="#" className="btn btn-block btn-danger">
                  <i className="fab fa-google-plus mr-2"></i> Sign in using
                  Google+
                </a>
              </div>
              <p className="mb-1">
                <a href="forgot-password.html">I forgot my password</a>
              </p>
              <p className="mb-0">
                <Link to="/signup" className="text-center">
                  New User?Create a New Account
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getProduct } from "../Store/ActionCreators/ProductActionCreators";
import { getMaincategory } from "../Store/ActionCreators/MaincategoryActionCreators";
import { getSubcategory } from "../Store/ActionCreators/SubcategoryActionCreators";
import { getBrand } from "../Store/ActionCreators/BrandActionCreators";

export default function Shop() {
  let [mc, setMc] = useState("All");
  let [sc, setSc] = useState("All");
  let [br, setBr] = useState("All");
  let [flag, setFlag] = useState(0);
  let shopProd = useSelector((state) => state.ProductStateData);
  let [shopProducts, setShopProducts] = useState(shopProd);

  let shopMain = useSelector((state) => state.MaincategoryStateData);
  let shopSub = useSelector((state) => state.SubcategoryStateData);
  let shopBrand = useSelector((state) => state.BrandStateData);

  let dispatch = useDispatch();
  function getSelectedData(mc, sc, br) {
    let p = [];
    if (mc === "All" && sc === "All" && br === "All") p = shopProd;
    else if (mc !== "All" && sc === "All" && br === "All")
      p = shopProd.filter((item) => item.maincategory === mc);
    else if (mc === "All" && sc !== "All" && br === "All")
      p = shopProd.filter((item) => item.subcategory === sc);
    else if (mc === "All" && sc === "All" && br !== "All")
      p = shopProd.filter((item) => item.brand === br);
    else if (mc !== "All" && sc !== "All" && br === "All")
      p = shopProd.filter(
        (item) => item.maincategory === mc && item.subcategory === sc
      );
    else if (mc !== "All" && sc === "All" && br !== "All")
      p = shopProd.filter(
        (item) => item.maincategory === mc && item.brand === br
      );
    else if (mc === "All" && sc !== "All" && br !== "All")
      p = shopProd.filter(
        (item) => item.subcategory === sc && item.brand === br
      );
    else if (mc !== "All" && sc !== "All" && br !== "All")
      p = shopProd.filter(
        (item) =>
          item.subcategory === sc &&
          item.brand === br &&
          item.maincategory === mc
      );

    setShopProducts(p);
  }

  function getSelected(e) {
    let name = e.target.name;
    let value = e.target.value;
    if (name === "maincategory") {
      setMc(value);
      getSelectedData(value, sc, br);
    } else if (name === "subcategory") {
      setSc(value);
      getSelectedData(mc, value, br);
    } else {
      setBr(value);
      getSelectedData(mc, sc, value);
    }
  }
  function getSort(e) {
    let value = e.target.value;
    if (value === "All") {
      setShopProducts(shopProd.sort((a, b) => a.id - b.id));
    } else if (value === "lowToHigh") {
      setShopProducts(shopProd.sort((a, b) => a.finalprice - b.finalprice));
    } else {
      setShopProducts(shopProd.sort((a, b) => b.finalprice - a.finalprice));
    }

    if (flag === 0) {
      setFlag(1);
    } else {
      setFlag(0);
    }
  }

  function genderCheck(gender) {
    let genderLength = shopProd.filter(
      (items) => items.maincategory === gender
    );
    return genderLength.length;
  }

  function getPriceFilter(e) {
    let value = e.target.value;
    let p = [];
    if (value === ">5000") {
      p = shopProd.filter((item) => item.finalprice >= 5000);
    } else {
      let min = value.split("-")[0];
      let max = value.split("-")[1];
      p = shopProd.filter(
        (item) => item.finalprice >= min && item.finalprice < max
      );
    }
    setShopProducts(p);
  }

  function getSizeFilter(e) {
    let value = e.target.value;
    setShopProducts(shopProd.filter((item) => item.size === value));
  }

  useEffect(() => {
    dispatch(getProduct());
    dispatch(getMaincategory());
    dispatch(getSubcategory());
    dispatch(getBrand());
    setShopProducts(shopProd);
  }, [shopProd.length]);
  console.log(shopProducts);
  return (
    <>
      <div className="bg-light py-3">
        <div className="container">
          <div className="row">
            <div className="col-md-12 mb-0">
              <Link to="/">Home</Link> <span className="mx-2 mb-0">/</span>{" "}
              <strong className="text-black">Shop</strong>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section">
        <div className="container">
          <div className="row mb-5">
            <div className="col-md-9 order-2">
              <div className="row">
                <div className="d-flex col-md-12 mb-5">
                  <div
                    className="d-flex flex-column dropdown mr-1 ml-md-auto"
                    style={{ width: "25%" }}
                  >
                    <label className="bg-secondary rounded text-light p-2">
                      Maincategory
                    </label>
                    <select name="maincategory" onChange={getSelected}>
                      <option value="All">All</option>
                      {shopMain.map((item, index) => {
                        return (
                          item.id !== 0 && (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          )
                        );
                      })}
                    </select>
                  </div>
                  <div
                    className="d-flex flex-column dropdown mr-1 ml-md-auto"
                    style={{ width: "25%" }}
                  >
                    <label className="bg-secondary rounded text-light p-2">
                      Subcategory
                    </label>
                    <select name="subcategory" onChange={getSelected}>
                      <option value="All">All</option>
                      {shopSub.map((item, index) => {
                        return (
                          item.id !== 0 && (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          )
                        );
                      })}
                    </select>
                  </div>
                  <div
                    className="d-flex flex-column dropdown mr-1 ml-md-auto"
                    style={{ width: "25%" }}
                  >
                    <label className="bg-secondary rounded text-light p-2">
                      Brand
                    </label>
                    <select name="brand" onChange={getSelected}>
                      <option value="All">All</option>
                      {shopBrand.map((item, index) => {
                        return (
                          item.id !== 0 && (
                            <option key={index} value={item.name}>
                              {item.name}
                            </option>
                          )
                        );
                      })}
                    </select>
                  </div>
                  <div
                    className="d-flex flex-column dropdown mr-1 ml-md-auto"
                    style={{ width: "25%" }}
                  >
                    <label className="bg-secondary rounded text-light p-2">
                      Sort By
                    </label>
                    <select name="sortBy" onChange={getSort}>
                      <option>Choose an Option</option>
                      <option value="All">All</option>
                      <option value="lowToHigh">Price low to high</option>
                      <option value="highToLow">Price high to low</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="row mb-5">
                {shopProducts &&
                  shopProducts.map((item, index) => {
                    return (
                      item.id !== 0 && (
                        <div
                          className="col-sm-6 col-lg-4 mb-4"
                          key={index}
                          data-aos="fade-up"
                        >
                          <div className="block-4 text-center border">
                            <figure className="block-4-image">
                              <Link to={`/single-product/${item.id}`}>
                                <img
                                  src={`assets/productimages/${item.pic1}`}
                                  alt="Image placeholder"
                                  className="w-100"
                                  height="200px"
                                />
                              </Link>
                            </figure>
                            <div className="block-4-text p-4">
                              <h3>
                                <a href="shop-single.html">{item.name}</a>
                              </h3>
                              <h3 className="mb-0 mt-2">
                                &#8377;
                                <del className="text-danger">
                                  {item.baseprice}
                                </del>
                                <sup>{item.finalprice}</sup>
                              </h3>
                              <p className="text-primary font-weight-bold">
                                {item.maincategory}
                              </p>
                              <p className="text-primary font-weight-bold">
                                Discount {item.discount}%
                              </p>
                            </div>
                          </div>
                        </div>
                      )
                    );
                  })}
              </div>
              <div className="row" data-aos="fade-up">
                <div className="col-md-12 text-center">
                  <div className="site-block-27">
                    <ul>
                      <li>
                        <a href="#">&lt;</a>
                      </li>
                      <li className="active">
                        <span>1</span>
                      </li>
                      <li>
                        <a href="#">2</a>
                      </li>
                      <li>
                        <a href="#">3</a>
                      </li>
                      <li>
                        <a href="#">4</a>
                      </li>
                      <li>
                        <a href="#">5</a>
                      </li>
                      <li>
                        <a href="#">&gt;</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3 order-1 mb-5 mb-md-0">
              <div className="border p-4 rounded mb-4">
                <h3 className="mb-3 h6 text-uppercase text-black d-block">
                  Categories
                </h3>
                <ul className="list-unstyled mb-0">
                  <li className="mb-1">
                    <span className="text-black d-flex">
                      <span>Male</span>
                      <span className="text-black ml-auto">
                        ( {genderCheck("Male")} )
                      </span>
                    </span>
                  </li>
                  <li className="mb-1">
                    <span className="text-black d-flex">
                      <span>Female</span>
                      <span className="text-black ml-auto">
                        ( {genderCheck("Female")} )
                      </span>
                    </span>
                  </li>
                  <li className="mb-1">
                    <span className="text-black d-flex">
                      <span>Children</span>
                      <span className="text-black ml-auto">
                        ( {genderCheck("Children")} )
                      </span>
                    </span>
                  </li>
                </ul>
              </div>

              <div className="border p-4 rounded mb-4">
                <div className="mb-4">
                  <h3 className="mb-3 h6 text-uppercase text-black d-block">
                    Filter by Price
                  </h3>
                  <div>
                    <input
                      type="radio"
                      name="amount"
                      id="amount"
                      value="0-1000"
                      onChange={getPriceFilter}
                    />
                    <span className="ml-2 text-black">&#8377; 0 - 1000</span>
                  </div>
                  <div>
                    <input
                      type="radio"
                      name="amount"
                      id="amount"
                      value="1001-2000"
                      onChange={getPriceFilter}
                    />
                    <span className="ml-2 text-black">&#8377; 1001 - 2000</span>
                  </div>
                  <div>
                    <input
                      type="radio"
                      name="amount"
                      id="amount"
                      value="2001-3000"
                      onChange={getPriceFilter}
                    />
                    <span className="ml-2 text-black">&#8377; 2001 - 3000</span>
                  </div>
                  <div>
                    <input
                      type="radio"
                      name="amount"
                      id="amount"
                      value="3001-4000"
                      onChange={getPriceFilter}
                    />
                    <span className="ml-2 text-black">&#8377; 3001 - 4000</span>
                  </div>
                  <div>
                    <input
                      type="radio"
                      name="amount"
                      id="amount"
                      value="4001-5000"
                      onChange={getPriceFilter}
                    />
                    <span className="ml-2 text-black">&#8377; 4001 - 5000</span>
                  </div>
                  <div>
                    <input
                      type="radio"
                      name="amount"
                      id="amount"
                      value=">5000"
                      onChange={getPriceFilter}
                    />
                    <span className="ml-2 text-black">{">"} &#8377; 5000</span>
                  </div>
                </div>

                <div className="mb-4">
                  <h3 className="mb-3 h6 text-uppercase text-black d-block">
                    Sizes
                  </h3>
                  <label htmlFor="sm" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="SM"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">SM</span>
                  </label>
                  <label htmlFor="md" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="MD"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">MD</span>
                  </label>
                  <label htmlFor="lg" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="LG"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">LG</span>
                  </label>
                  <label htmlFor="xl" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="XL"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">XL</span>
                  </label>
                  <label htmlFor="xll" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="XXL"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">XXL</span>
                  </label>
                  <label htmlFor="24" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="24"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">24</span>
                  </label>
                  <label htmlFor="26" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="26"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">26</span>
                  </label>
                  <label htmlFor="28" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="28"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">28</span>
                  </label>
                  <label htmlFor="30" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="30"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">30</span>
                  </label>
                  <label htmlFor="32" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="32"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">32</span>
                  </label>
                  <label htmlFor="34" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="34"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">34</span>
                  </label>
                  <label htmlFor="36" className="d-flex">
                    <input
                      type="radio"
                      name="size"
                      value="36"
                      onChange={getSizeFilter}
                      className="mr-2 mt-1"
                    />
                    <span className="text-black">36</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

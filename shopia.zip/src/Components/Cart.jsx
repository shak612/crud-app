import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  deleteCart,
  getCart,
  updateCart,
} from "../Store/ActionCreators/CartActionCreators";

export default function Cart() {
  let [cart, setCart] = useState([]);
  let [total, setTotal] = useState(0);
  let [shipping, setShipping] = useState(0);
  let [final, setFinal] = useState(0);
  let carts = useSelector((state) => state.CartStateData);
  let dispatch = useDispatch();

  function getAPIData() {
    dispatch(getCart());
    let data = carts.filter(
      (item) => item.userid === localStorage.getItem("userid")
    );
    setCart(data);
    let total = 0;
    let shipping = 0;
    let final = 0;
    for (let item of data) {
      total = total + item.total;
    }
    if (total > 0 && total <= 1000) {
      shipping = 150;
    }

    final = total + shipping;

    setTotal(total);
    setShipping(shipping);
    setFinal(final);
  }

  function deleteRecord(id) {
    dispatch(deleteCart({ id: id }));
    getAPIData();
  }

  function updateRecord(id, op) {
    let item = cart.find((item) => item.id === id);
    console.log(item);
    if (op === "dec" && item.qty === 1) return;
    else if (op === "dec") {
      item.qty = item.qty - 1;
      item.total = item.total - item.price;
    } else {
      item.qty = item.qty + 1;
      item.total = item.total + item.price;
    }
    dispatch(updateCart(item));
    getAPIData();
  }

  useEffect(() => {
    getAPIData();
  }, [carts.length]);

  return (
    <>
      <div className="bg-light py-3">
        <div className="container">
          <div className="row">
            <div className="col-md-12 mb-0">
              <Link to="/">Home</Link> <span className="mx-2 mb-0">/</span>{" "}
              <strong className="text-black">Cart</strong>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section">
        <div className="container">
          <div className="row mb-5">
            <form className="col-md-12" method="post">
              <div className="site-blocks-table">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th className="product-thumbnail">Image</th>
                      <th className="product-name">Product</th>
                      <th className="product-name">Color</th>
                      <th className="product-name">Size</th>
                      <th className="product-price">Price</th>
                      <th className="product-quantity">Quantity</th>
                      <th className="product-total">Total</th>
                      <th className="product-remove">Remove</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.map((item, index) => (
                      <tr key={index}>
                        <td className="product-thumbnail">
                          <img
                            src={`/assets/productimages/${item.pic}`}
                            height="100px"
                            width="100px"
                            alt="Image"
                            className="rounded"
                          />
                        </td>
                        <td className="product-name">{item.name}</td>
                        <td>{item.color}</td>
                        <td>{item.size}</td>
                        <td>&#8377;{item.price}</td>
                        <td>
                          <div
                            className="input-group mb-3"
                            style={{ maxWidth: "120px" }}
                          >
                            <div className="input-group-prepend">
                              <button
                                className="btn btn-outline-primary js-btn-minus"
                                type="button"
                                onClick={() => updateRecord(item.id, "dec")}
                              >
                                -
                              </button>
                            </div>
                            <span style={{ margin: "6px 6px" }}>
                              {item.qty}
                            </span>
                            <div className="input-group-append">
                              <button
                                className="btn btn-outline-primary js-btn-plus"
                                type="button"
                                onClick={() => updateRecord(item.id, "inc")}
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </td>
                        <td>&#8377;{item.total}</td>
                        <td>
                          <button
                            type="button"
                            className="btn btn-primary btn-sm"
                            onClick={() => deleteRecord(item.id)}
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </form>
          </div>

          <div className="row">
            <div className="col-md-6">
              <div className="row mb-5">
                <div className="col-md-6">
                  <Link
                    to="/shop"
                    className="btn btn-outline-primary btn-sm btn-block"
                  >
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-6 pl-5">
              <div className="row justify-content-end">
                <div className="col-md-7">
                  <div className="row">
                    <div className="col-md-12 text-right border-bottom mb-5">
                      <h3 className="text-black h4 text-uppercase">
                        Cart Totals
                      </h3>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <span className="text-black">Subtotal</span>
                    </div>
                    <div className="col-md-6 text-right">
                      <strong className="text-black">&#8377;{total}</strong>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <span className="text-black">Shipping</span>
                    </div>
                    <div className="col-md-6 text-right">
                      <strong className="text-black">&#8377;{shipping}</strong>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-md-6">
                      <span className="text-black">Final</span>
                    </div>
                    <div className="col-md-6 text-right">
                      <strong className="text-black">&#8377;{final}</strong>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-12">
                      <Link
                        className="btn btn-primary btn-sm py-3 btn-block"
                        to="/checkout"
                      >
                        Proceed To Checkout
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

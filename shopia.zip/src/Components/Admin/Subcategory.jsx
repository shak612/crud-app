import React, { useEffect } from "react";
import LeftNav from "./LeftNav";
import Box from "@mui/material/Box";
import { DataGrid } from "@mui/x-data-grid";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteSubcategory,
  getSubcategory,
} from "../../Store/ActionCreators/SubcategoryActionCreators";
import { Button } from "@mui/material";

export default function Subcategory() {
  let subcategory = useSelector((state) => state.SubcategoryStateData);
  let dispatch = useDispatch();
  let navigate = useNavigate();
  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 90,
    },
    {
      field: "name",
      headerName: "Name",
      width: 150,
    },
    {
      field: "edit",
      headerName: "Edit",
      sortable: false,
      renderCell: ({ row }) => (
        <Button
          onClick={() => {
            navigate("/admin-update-subcategory/" + row.id);
          }}
        >
          <span className="material-symbols-outlined">edit</span>
        </Button>
      ),
    },
    {
      field: "delete",
      headerName: "Delete",
      sortable: false,
      renderCell: ({ row }) => (
        <Button onClick={() => dispatch(deleteSubcategory({ id: row.id }))}>
          <span className="material-symbols-outlined">delete_forever</span>
        </Button>
      ),
    },
  ];

  let rows = [];
  for (let item of subcategory) {
    rows.push(item);
  }
  function getAPIData() {
    dispatch(getSubcategory());
  }
  useEffect(() => {
    getAPIData();
  }, []);
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-3 col-12">
          <LeftNav />
        </div>
        <div className="col-md-9 col-12">
          <h5 className="p-3">
            Subcategory
            <Link to="/admin-add-subcategory">
              <span className="material-symbols-outlined float-right">add</span>
            </Link>
          </h5>
          <Box sx={{ height: 400, width: "100%" }}>
            <DataGrid
              rows={rows}
              columns={columns}
              pageSize={5}
              rowsPerPageOptions={[5]}
              // disableSelectionOnClick
              experimentalFeatures={{ newEditingApi: true }}
            />
          </Box>
        </div>
      </div>
    </div>
  );
}

import React from "react";
import { Link } from "react-router-dom";
import LeftNav from "./LeftNav";

export default function AdminHome() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-3 col-12">
          <LeftNav />
        </div>
        <div className="col-md-9 col-12">
          <div
            className="card mb-3"
            style={{ maxWidth: "100%", height: "100%" }}
          >
            <div className="row">
              <div className="col-md-6">
                <img
                  src="../assets/images/person_4.jpg"
                  className="img-fluid rounded-start"
                  alt="..."
                />
                <h1 style={{ marginLeft: "130px" }}>Admin</h1>
              </div>
              <div className="col-md-6">
                <table className="table table-bordered">
                  <tbody>
                    <tr>
                      <th>Name:</th>
                      <td>Shakir Mansuri</td>
                    </tr>
                    <tr>
                      <th>User Name:</th>
                      <td>Admin</td>
                    </tr>
                    <tr>
                      <th>Email Address:</th>
                      <td>shakirmanusri612@gmail.com</td>
                    </tr>
                    <tr>
                      <th>Phone:</th>
                      <td>8851290425</td>
                    </tr>
                    <tr>
                      <th>Address:</th>
                      <td>Ghaziabad Uttar Pradesh</td>
                    </tr>
                    <tr>
                      <td colSpan={2}>
                        <Link to="#" className="btn btn-primary">
                          Update Profile
                        </Link>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

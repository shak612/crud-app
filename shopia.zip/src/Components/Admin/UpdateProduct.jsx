import React, { useEffect, useState } from "react";
import LeftNav from "./LeftNav";
import { Link } from "react-router-dom";
import { updateProduct } from "../../Store/ActionCreators/ProductActionCreators";
import { getMaincategory } from "../../Store/ActionCreators/MaincategoryActionCreators";
import { getSubcategory } from "../../Store/ActionCreators/SubcategoryActionCreators";
import { getBrand } from "../../Store/ActionCreators/BrandActionCreators";

import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

export default function UpdateProduct() {
  let [data, setData] = useState({
    name: "",
    maincategory: "",
    subcategory: "",
    brand: "",
    color: "",
    size: "",
    stock: "In Stock",
    baseprice: 0,
    discount: 0,
    description: "This is Products",
    finalprice: "",
    pic1: "",
    pic2: "",
    pic3: "",
    pic4: "",
  });
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  let Product = useSelector((state) => state.ProductStateData);
  const maincategory = useSelector((state) => state.MaincategoryStateData);
  const subcategory = useSelector((state) => state.SubcategoryStateData);
  const brand = useSelector((state) => state.BrandStateData);

  function getData(e) {
    let name = e.target.name;
    let value = e.target.value;
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
  }

  function getFile(e) {
    let name = e.target.name;
    let value = e.target.files[0].name;
    setData((old) => {
      return {
        ...old,
        [name]: value,
      };
    });
  }

  function postData(e) {
    e.preventDefault();
    let fp = data.baseprice - (data.baseprice * data.discount) / 100;
    let item = {
      id: id,
      name: data.name,
      maincategory: data.maincategory,
      subcategory: data.subcategory,
      brand: data.brand,
      color: data.color,
      size: data.size,
      baseprice: data.baseprice,
      discount: data.discount,
      finalprice: fp,
      stock: data.stock,
      description: data.description,
      pic1: data.pic1,
      pic2: data.pic2,
      pic3: data.pic3,
      pic4: data.pic4,
    };
    dispatch(updateProduct(item));
    navigate("/admin-product");
  }

  useEffect(() => {
    setData(Product.find((item) => item.id === Number(id)));
    dispatch(getMaincategory());
    dispatch(getSubcategory());
    dispatch(getBrand());
  }, []);

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-3 col-12">
          <LeftNav />
        </div>
        <div className="col-md-9 col-12">
          <h5 className="p-3">
            Product
            <Link to="/admin-add-Product">
              <span className="material-symbols-outlined float-right">add</span>
            </Link>
          </h5>
          <form onSubmit={postData}>
            <div className="p-3 p-lg-5 border">
              <div className="form-group row">
                <div className="col-md-12">
                  <label htmlFor="name" className="text-black">
                    Name <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    name="name"
                    value={data.name}
                    onChange={getData}
                    placeholder="Enter the Category Name"
                  />
                </div>
              </div>
              <div className="row mb-3">
                <div className="col-lg-3 col-md-6 col-12">
                  <label htmlFor="maincategory" className="text-black">
                    Maincategory <span className="text-danger">*</span>
                  </label>
                  <select
                    className="form-control"
                    name="maincategory"
                    onChange={getData}
                  >
                    {maincategory.map(
                      (item, index) =>
                        item.id !== 0 && (
                          <option
                            key={index}
                            selected={data.maincategory === item.name}
                          >
                            {item.name}
                          </option>
                        )
                    )}
                  </select>
                </div>
                <div className="col-lg-3 col-md-6 col-12">
                  <label htmlFor="subcategory" className="text-black">
                    Subcategory <span className="text-danger">*</span>
                  </label>
                  <select
                    className="form-control"
                    name="subcategory"
                    onChange={getData}
                  >
                    {subcategory.map(
                      (item, index) =>
                        item.id !== 0 && (
                          <option
                            key={index}
                            selected={data.subcategory === item.name}
                          >
                            {item.name}
                          </option>
                        )
                    )}
                  </select>
                </div>
                <div className="col-lg-3 col-md-6 col-12">
                  <label htmlFor="brand" className="text-black">
                    Brand <span className="text-danger">*</span>
                  </label>
                  <select
                    className="form-control"
                    name="brand"
                    onChange={getData}
                  >
                    {brand.map(
                      (item, index) =>
                        item.id !== 0 && (
                          <option
                            key={index}
                            selected={data.brand === item.name}
                          >
                            {item.name}
                          </option>
                        )
                    )}
                  </select>
                </div>
                <div className="col-lg-3 col-md-6 col-12">
                  <label htmlFor="stock" className="text-black">
                    Stock <span className="text-danger">*</span>
                  </label>
                  <select className="form-control" name="brand">
                    <option
                      value="In Stock"
                      selected={data.stock === "In Stock"}
                    >
                      In Stock
                    </option>
                    <option
                      value="Out of Stock"
                      selected={data.stock === "Out of Stock"}
                    >
                      Out of Stock
                    </option>
                  </select>
                </div>
              </div>
              <div className="row mb-3">
                <div className="col-md-6 col-12">
                  <label htmlFor="color" className="text-black">
                    Color <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="color"
                    name="color"
                    value={data.color}
                    onChange={getData}
                    placeholder="Enter Color Name"
                  />
                </div>
                <div className="col-md-6 col-12">
                  <label htmlFor="size" className="text-black">
                    Size <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="size"
                    name="size"
                    value={data.size}
                    onChange={getData}
                    placeholder="Enter size"
                  />
                </div>
              </div>
              <div className="row mb-3">
                <div className="col-md-6 col-12">
                  <label htmlFor="baseprice" className="text-black">
                    Baseprice <span className="text-danger">*</span>
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="baseprice"
                    name="baseprice"
                    value={data.baseprice}
                    onChange={getData}
                    placeholder="Enter baseprice"
                  />
                </div>
                <div className="col-md-6 col-12">
                  <label htmlFor="discount" className="text-black">
                    Discount <span className="text-danger">*</span>
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="discount"
                    name="discount"
                    value={data.discount}
                    onChange={getData}
                    placeholder="Enter discount"
                  />
                </div>
              </div>
              <div className="mb-3">
                <label htmlFor="description" className="text-black">
                  Description <span className="text-danger">*</span>
                </label>
                <textarea
                  className="form-control"
                  id="description"
                  name="description"
                  rows="5"
                  value={data.description}
                  onChange={getData}
                ></textarea>
              </div>
              <div className="row mb-3">
                <div className="col-md-6 col-12">
                  <label htmlFor="pic1" className="text-black">
                    Pic1 <span className="text-danger">*</span>
                  </label>
                  <input
                    className="form-controle"
                    type="file"
                    name="pic1"
                    id="pic1"
                    // value={data.pic1}
                    onChange={getFile}
                  />
                </div>
                <div className="col-md-6 col-12">
                  <label htmlFor="pic2" className="text-black">
                    Pic2 <span className="text-danger">*</span>
                  </label>
                  <input
                    className="form-controle"
                    type="file"
                    name="pic2"
                    id="pic2"
                    // value={data.pic2}
                    onChange={getFile}
                  />
                </div>
              </div>
              <div className="row mb-3">
                <div className="col-md-6 col-12">
                  <label htmlFor="pic3" className="text-black">
                    Pic3 <span className="text-danger">*</span>
                  </label>
                  <input
                    className="form-controle"
                    type="file"
                    name="pic3"
                    id="pic3"
                    // value={data.pic3}
                    onChange={getFile}
                  />
                </div>
                <div className="col-md-6 col-12">
                  <label htmlFor="pic4" className="text-black">
                    Pic4 <span className="text-danger">*</span>
                  </label>
                  <input
                    className="form-controle"
                    type="file"
                    name="pic4"
                    id="pic4"
                    // value={data.pic4}
                    onChange={getFile}
                  />
                </div>
              </div>
              <div className="mb-3">
                <button
                  type="submit"
                  className="btn btn-primary btn-lg btn-block"
                >
                  Update
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

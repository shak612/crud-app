import React, { useEffect } from "react";
import LeftNav from "./LeftNav";
import Box from "@mui/material/Box";
import { DataGrid } from "@mui/x-data-grid";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteProduct,
  getProduct,
} from "../../Store/ActionCreators/ProductActionCreators";
import { Button } from "@mui/material";

export default function Product() {
  let product = useSelector((state) => state.ProductStateData);
  let dispatch = useDispatch();
  let navigate = useNavigate();
  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 50,
    },
    {
      field: "name",
      headerName: "Name",
      width: 140,
    },
    {
      field: "maincategory",
      headerName: "Maincategory",
      width: 100,
    },
    {
      field: "subcategory",
      headerName: "Subcategory",
      width: 120,
    },
    {
      field: "brand",
      headerName: "Brand",
      width: 100,
    },
    {
      field: "color",
      headerName: "Color",
      width: 70,
    },
    {
      field: "size",
      headerName: "Size",
      width: 50,
    },
    {
      field: "baseprice",
      headerName: "Base Price",
      width: 100,
    },
    {
      field: "discount",
      headerName: "Discount",
      width: 70,
    },
    {
      field: "finalprice",
      headerName: "Final Price",
      width: 100,
    },
    {
      field: "stock",
      headerName: "Stock",
      width: 100,
    },
    {
      field: "pic1",
      headerName: "Pic1",
      width: 60,
      renderCell: ({ row }) => (
        <img
          classNmae="rounded"
          src={`assets/productimages/${row.pic1}`}
          height="50px"
          width="100%"
          alt=""
        />
      ),
    },
    {
      field: "pic2",
      headerName: "Pic2",
      width: 60,
      renderCell: ({ row }) => (
        <img
          classNmae="rounded"
          src={`assets/productimages/${row.pic2}`}
          height="50px"
          width="100%"
          alt=""
        />
      ),
    },
    {
      field: "pic3",
      headerName: "Pic3",
      width: 60,
      renderCell: ({ row }) => (
        <img
          classNmae="rounded"
          src={`assets/productimages/${row.pic3}`}
          height="50px"
          width="100%"
          alt=""
        />
      ),
    },
    {
      field: "pic4",
      headerName: "Pic4",
      width: 60,
      renderCell: ({ row }) => (
        <img
          classNmae="rounded"
          src={`assets/productimages/${row.pic4}`}
          height="50px"
          width="100%"
          alt=""
        />
      ),
    },
    {
      field: "edit",
      headerName: "Edit",
      width: 60,
      sortable: false,
      renderCell: ({ row }) => (
        <Button
          onClick={() => {
            navigate("/admin-update-product/" + row.id);
          }}
        >
          <span className="material-symbols-outlined">edit</span>
        </Button>
      ),
    },
    {
      field: "delete",
      headerName: "Delete",
      width: 70,
      sortable: false,
      renderCell: ({ row }) => (
        <Button onClick={() => dispatch(deleteProduct({ id: row.id }))}>
          <span className="material-symbols-outlined">delete_forever</span>
        </Button>
      ),
    },
  ];

  let rows = [];
  for (let item of product) {
    rows.push(item);
  }
  function getAPIData() {
    dispatch(getProduct());
  }
  useEffect(() => {
    getAPIData();
  }, []);
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-3 col-12">
          <LeftNav />
        </div>
        <div className="col-md-9 col-12">
          <h5 className="p-3">
            Product
            <Link to="/admin-add-product">
              <span className="material-symbols-outlined float-right">add</span>
            </Link>
          </h5>
          <Box sx={{ height: 400, width: "100%" }}>
            <DataGrid
              rows={rows}
              columns={columns}
              pageSize={5}
              rowsPerPageOptions={[5]}
              // disableSelectionOnClick
              experimentalFeatures={{ newEditingApi: true }}
            />
          </Box>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from "react";
import LeftNav from "./LeftNav";
import { Link } from "react-router-dom";
import { updateMaincategory } from "../../Store/ActionCreators/MaincategoryActionCreators";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

export default function UpdateMaincategory() {
  let [name, setName] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  let maincategory = useSelector((state) => state.MaincategoryStateData);
  function getData(e) {
    setName(e.target.value);
  }

  async function postData(e) {
    e.preventDefault();
    let data = maincategory.find((item) => item.name === name);
    if (data) alert("Maincategory is already Exist!!");
    else {
      dispatch(updateMaincategory({ id: id, name: name }));
      navigate("/admin-maincategory");
    }
  }

  useEffect(() => {
    let maincat = maincategory.find((item) => item.id === Number(id));
    setName(maincat.name);
  }, [maincategory]);

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-3 col-12">
          <LeftNav />
        </div>
        <div className="col-md-9 col-12">
          <h5 className="p-3">
            Maincategory
            <Link to="/admin-add-maincategory">
              <span className="material-symbols-outlined float-right">add</span>
            </Link>
          </h5>
          <form onSubmit={postData}>
            <div className="p-3 p-lg-5 border">
              <div className="form-group row">
                <div className="col-md-12">
                  <label htmlFor="name" className="text-black">
                    Name <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    name="name"
                    value={name}
                    onChange={getData}
                    placeholder="Enter the Category Name"
                  />
                </div>
              </div>
              <div className="form-group row">
                <div className="col-lg-12">
                  <button
                    type="submit"
                    className="btn btn-primary btn-lg btn-block"
                  >
                    Update
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { getProduct } from "../Store/ActionCreators/ProductActionCreators";
import { getCart, addCart } from "../Store/ActionCreators/CartActionCreators";
import {
  getWishlist,
  addWishlist,
} from "../Store/ActionCreators/WishlistActionCreators";

export default function SingleProduct() {
  let [prod, setProd] = useState({});
  let [value, setValue] = useState(1);
  let product = useSelector((state) => state.ProductStateData);
  let cart = useSelector((state) => state.CartStateData);
  let wishlist = useSelector((state) => state.WishlistStateData);
  let dispatch = useDispatch();
  const { id } = useParams();
  let navigate = useNavigate();

  function getAPIData() {
    dispatch(getProduct());
    dispatch(getCart());
    dispatch(getWishlist());
  }

  function getValue(e) {
    setValue(e.target.value);
  }
  function addToCart() {
    let data = cart.find(
      (item) =>
        item.productid === prod.id &&
        item.userid === localStorage.getItem("userid")
    );
    if (data) navigate("/cart");
    else {
      let items = {
        productid: prod.id,
        userid: localStorage.getItem("userid"),
        name: prod.name,
        color: prod.color,
        size: prod.size,
        price: prod.finalprice,
        qty: value,
        total: value * prod.finalprice,
        pic: prod.pic1,
      };
      dispatch(addCart(items));
      navigate("/cart");
    }
  }

  function addToWishlist() {
    let data = wishlist.find(
      (item) =>
        item.productid === prod.id &&
        item.userid === localStorage.getItem("userid")
    );
    if (data) navigate("/profile");
    else {
      let items = {
        productid: prod.id,
        userid: localStorage.getItem("userid"),
        name: prod.name,
        color: prod.color,
        size: prod.size,
        price: prod.finalprice,
        pic: prod.pic1,
      };
      dispatch(addWishlist(items));
      navigate("/profile");
    }
  }

  useEffect(() => {
    getAPIData();
    let p = product.find((item) => item.id === Number(id));
    if (p) setProd(p);
  }, [product.length]);

  return (
    <>
      <div className="bg-light py-3">
        <div className="container">
          <div className="row">
            <div className="col-md-12 mb-0">
              <Link to="/">Home</Link> <span className="mx-2 mb-0">/</span>{" "}
              <strong className="text-black">Tank Top T-Shirt</strong>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div
                id="carouselExampleIndicators"
                className="carousel slide"
                data-ride="carousel"
              >
                <ol className="carousel-indicators">
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="0"
                    className="active"
                  ></li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="1"
                  ></li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="2"
                  ></li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="3"
                  ></li>
                </ol>
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img
                      className="d-block w-100"
                      height="550px"
                      src={`/assets/productimages/${prod.pic1}`}
                      alt="First slide"
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      className="d-block w-100"
                      height="550px"
                      src={`/assets/productimages/${prod.pic2}`}
                      alt="Second slide"
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      className="d-block w-100"
                      height="550px"
                      src={`/assets/productimages/${prod.pic3}`}
                      alt="Third slide"
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      className="d-block w-100"
                      height="550px"
                      src={`/assets/productimages/${prod.pic4}`}
                      alt="Fourth slide"
                    />
                  </div>
                </div>
                <a
                  className="carousel-control-prev"
                  href="#carouselExampleIndicators"
                  role="button"
                  data-slide="prev"
                >
                  <span
                    className="carousel-control-prev-icon"
                    aria-hidden="true"
                  ></span>
                  <span className="sr-only">Previous</span>
                </a>
                <a
                  className="carousel-control-next"
                  href="#carouselExampleIndicators"
                  role="button"
                  data-slide="next"
                >
                  <span
                    className="carousel-control-next-icon"
                    aria-hidden="true"
                  ></span>
                  <span className="sr-only">Next</span>
                </a>
              </div>
            </div>
            <div className="col-md-6">
              <table className="table table-bordered">
                <tbody>
                  <tr>
                    <td colSpan={2} className="text-center">
                      <strong>{prod.name}</strong>
                    </td>
                  </tr>
                  <tr>
                    <th>Maincategory</th>
                    <td>{prod.maincategory}</td>
                  </tr>
                  <tr>
                    <th>Subcategory</th>
                    <td>{prod.subcategory}</td>
                  </tr>
                  <tr>
                    <th>Brand</th>
                    <td>{prod.brand}</td>
                  </tr>
                  <tr>
                    <th>Color</th>
                    <td>{prod.color}</td>
                  </tr>
                  <tr>
                    <th>Size</th>
                    <td>{prod.size}</td>
                  </tr>
                  <tr>
                    <th>Price</th>
                    <td>
                      &#8377;<del className="text-danger">{prod.baseprice}</del>
                      <sup>{prod.finalprice}</sup>
                    </td>
                  </tr>
                  <tr>
                    <th>Discount</th>
                    <td>{prod.discount}</td>
                  </tr>
                  <tr>
                    <th>Stock</th>
                    <td>{prod.stock}</td>
                  </tr>
                  <tr>
                    <th>Description</th>
                    <td>{prod.description}</td>
                  </tr>
                </tbody>
              </table>
              <div className="mb-1">
                <div className="input-group mb-3" style={{ maxWidth: "120px" }}>
                  <div className="input-group-prepend">
                    <button
                      className="btn btn-outline-primary js-btn-minus"
                      type="button"
                      onClick={() => {
                        if (value > 1) setValue((prev) => prev - 1);
                      }}
                    >
                      -
                    </button>
                  </div>
                  <input
                    type="text"
                    className="form-control text-center"
                    value={value}
                    onChange={getValue}
                    placeholder=""
                    aria-label="Example text with button addon"
                    aria-describedby="button-addon1"
                  />
                  <div className="input-group-append">
                    <button
                      className="btn btn-outline-primary js-btn-plus"
                      type="button"
                      onClick={() => {
                        setValue((prev) => prev + 1);
                      }}
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <p>
                  <button
                    onClick={addToCart}
                    className="buy-now btn btn-sm btn-primary"
                  >
                    Add to Cart
                  </button>
                </p>
                <p>
                  <button
                    onClick={addToWishlist}
                    className="buy-now btn btn-sm btn-primary"
                  >
                    Wishlist
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

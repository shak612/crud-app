import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_CHECKOUT,
  DELETE_CHECKOUT,
  GET_CHECKOUT,
  RED_ADD_CHECKOUT,
  RED_DELETE_CHECKOUT,
  RED_GET_CHECKOUT,
  RED_UPDATE_CHECKOUT,
  UPDATE_CHECKOUT,
} from "../Constant";
import {
  addCheckoutService,
  deleteCheckoutService,
  setCheckoutService,
  updateCheckoutService,
} from "../services";

function* getCheckoutSaga() {
  let response = yield setCheckoutService();
  yield put({
    type: RED_GET_CHECKOUT,
    result: "Done",
    data: response,
  });
}

function* createCheckoutSaga(data) {
  //executer
  let response = yield addCheckoutService(data);
  yield put({
    type: RED_ADD_CHECKOUT,
    result: "Done",
    data: response,
  });
}

function* updateCheckoutSaga(data) {
  //executer
  yield updateCheckoutService(data.payload);
  yield put({
    type: RED_UPDATE_CHECKOUT,
    result: "Done",
    data: data.payload,
  });
}

function* deleteCheckoutSaga(data) {
  yield deleteCheckoutService(data);
  yield put({ type: RED_DELETE_CHECKOUT, result: "Done", data: data.payload });
}

export default function* checkoutSaga() {
  //watcher
  yield takeEvery(ADD_CHECKOUT, createCheckoutSaga);
  yield takeEvery(GET_CHECKOUT, getCheckoutSaga);
  yield takeEvery(UPDATE_CHECKOUT, updateCheckoutSaga);
  yield takeEvery(DELETE_CHECKOUT, deleteCheckoutSaga);
}

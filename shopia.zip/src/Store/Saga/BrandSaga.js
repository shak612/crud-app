import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_BRAND,
  DELETE_BRAND,
  GET_BRAND,
  RED_ADD_BRAND,
  RED_DELETE_BRAND,
  RED_GET_BRAND,
  RED_UPDATE_BRAND,
  UPDATE_BRAND,
} from "../Constant";
import {
  addbrandService,
  deleteBrandService,
  setBrandService,
  updateBrandService,
} from "../services";

function* getBrandSaga() {
  let response = yield setBrandService();
  yield put({
    type: RED_GET_BRAND,
    result: "Done",
    data: response,
  });
}

function* createBrandSaga(data) {
  //executer
  let response = yield addbrandService(data);
  yield put({
    type: RED_ADD_BRAND,
    result: "Done",
    data: response,
  });
}

function* updateBrandSaga(data) {
  //executer
  yield updateBrandService(data.payload);
  yield put({
    type: RED_UPDATE_BRAND,
    result: "Done",
    data: data.payload,
  });
}

function* deleteBrandSaga(data) {
  yield deleteBrandService(data);
  yield put({ type: RED_DELETE_BRAND, result: "Done", data: data.payload });
}

export default function* brandSaga() {
  //watcher
  yield takeEvery(ADD_BRAND, createBrandSaga);
  yield takeEvery(GET_BRAND, getBrandSaga);
  yield takeEvery(UPDATE_BRAND, updateBrandSaga);
  yield takeEvery(DELETE_BRAND, deleteBrandSaga);
}

import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_PRODUCT,
  DELETE_PRODUCT,
  GET_PRODUCT,
  RED_ADD_PRODUCT,
  RED_DELETE_PRODUCT,
  RED_GET_PRODUCT,
  RED_UPDATE_PRODUCT,
  UPDATE_PRODUCT,
} from "../Constant";
import {
  addproductService,
  deleteProductService,
  setProductService,
  updateProductService,
} from "../services";

function* getProductSaga() {
  let response = yield setProductService();
  yield put({
    type: RED_GET_PRODUCT,
    result: "Done",
    data: response,
  });
}

function* createProductSaga(data) {
  //executer
  let response = yield addproductService(data);
  yield put({
    type: RED_ADD_PRODUCT,
    result: "Done",
    data: response,
  });
}

function* updateProductSaga(data) {
  //executer
  yield updateProductService(data.payload);
  yield put({
    type: RED_UPDATE_PRODUCT,
    result: "Done",
    data: data.payload,
  });
}

function* deleteProductSaga(data) {
  yield deleteProductService(data);
  yield put({ type: RED_DELETE_PRODUCT, result: "Done", data: data.payload });
}

export default function* productSaga() {
  //watcher
  yield takeEvery(ADD_PRODUCT, createProductSaga);
  yield takeEvery(GET_PRODUCT, getProductSaga);
  yield takeEvery(UPDATE_PRODUCT, updateProductSaga);
  yield takeEvery(DELETE_PRODUCT, deleteProductSaga);
}

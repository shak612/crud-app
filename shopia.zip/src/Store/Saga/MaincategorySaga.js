import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_MAINCATEGORY,
  DELETE_MAINCATEGORY,
  GET_MAINCATEGORY,
  RED_ADD_MAINCATEGORY,
  RED_DELETE_MAINCATEGORY,
  RED_GET_MAINCATEGORY,
  RED_UPDATE_MAINCATEGORY,
  UPDATE_MAINCATEGORY,
} from "../Constant";
import {
  addmaincategoryService,
  deleteMaincategoryService,
  setMaincategoryService,
  updateMaincategoryService,
} from "../services";

function* getMaincategorySaga() {
  let response = yield setMaincategoryService();
  yield put({
    type: RED_GET_MAINCATEGORY,
    result: "Done",
    data: response,
  });
}

function* createMaincategorySaga(data) {
  //executer
  let response = yield addmaincategoryService(data);
  yield put({
    type: RED_ADD_MAINCATEGORY,
    result: "Done",
    data: response,
  });
}

function* updateMaincategorySaga(data) {
  //executer
  yield updateMaincategoryService(data.payload);
  yield put({
    type: RED_UPDATE_MAINCATEGORY,
    result: "Done",
    data: data.payload,
  });
}

function* deleteMaincategorySaga(data) {
  yield deleteMaincategoryService(data);
  yield put({
    type: RED_DELETE_MAINCATEGORY,
    result: "Done",
    data: data.payload,
  });
}

export default function* maincategorySaga() {
  //watcher
  yield takeEvery(ADD_MAINCATEGORY, createMaincategorySaga);
  yield takeEvery(GET_MAINCATEGORY, getMaincategorySaga);
  yield takeEvery(UPDATE_MAINCATEGORY, updateMaincategorySaga);
  yield takeEvery(DELETE_MAINCATEGORY, deleteMaincategorySaga);
}

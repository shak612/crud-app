import { takeEvery, put } from "@redux-saga/core/effects";
import {
  REGISTER_USER,
  DELETE_USER,
  GET_USER,
  RED_REGISTER_USER,
  RED_DELETE_USER,
  RED_GET_USER,
  RED_UPDATE_USER,
  UPDATE_USER,
  RED_GET_SINGLE_USER,
  GET_SINGLE_USER,
  LOGIN,
  RED_LOGIN,
} from "../Constant";
import {
  addUserService,
  deleteUserService,
  setUserService,
  updateUserService,
  setSingleUserService,
} from "../services";

function* getUserSaga() {
  let response = yield setUserService();
  yield put({
    type: RED_GET_USER,
    result: "Done",
    data: response,
  });
}

function* getSingleUserSaga(data) {
  let response = yield setSingleUserService(data);
  yield put({
    type: RED_GET_SINGLE_USER,
    result: "Done",
    data: response,
  });
}

function* loginSaga(data) {
  let response = yield setUserService();
  let user = response.find(
    (item) =>
      item.username === data.payload.username &&
      item.password === data.payload.password
  );
  if (user) {
    yield put({
      type: RED_LOGIN,
      result: "Done",
      data: user,
    });
  } else {
    yield put({
      type: RED_LOGIN,
      result: "Fail",
      data: "Invalid user name or password",
    });
  }
}

function* createUserSaga(data) {
  //executer
  let response = yield addUserService(data);
  yield put({
    type: RED_REGISTER_USER,
    result: "Done",
    data: response,
  });
}

function* updateUserSaga(data) {
  //executer
  yield updateUserService(data.payload);
  yield put({
    type: RED_UPDATE_USER,
    result: "Done",
    data: data.payload,
  });
}

function* deleteUserSaga(data) {
  yield deleteUserService(data);
  yield put({ type: RED_DELETE_USER, result: "Done", data: data.payload });
}

export default function* userSaga() {
  //watcher
  yield takeEvery(REGISTER_USER, createUserSaga);
  yield takeEvery(GET_USER, getUserSaga);
  yield takeEvery(UPDATE_USER, updateUserSaga);
  yield takeEvery(DELETE_USER, deleteUserSaga);
  yield takeEvery(GET_SINGLE_USER, getSingleUserSaga);
  yield takeEvery(GET_SINGLE_USER, getSingleUserSaga);
  yield takeEvery(LOGIN, loginSaga);
}

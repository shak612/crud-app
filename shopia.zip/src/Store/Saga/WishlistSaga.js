import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_WISHLIST,
  DELETE_WISHLIST,
  GET_WISHLIST,
  RED_ADD_WISHLIST,
  RED_DELETE_WISHLIST,
  RED_GET_WISHLIST,
} from "../Constant";
import {
  addWishlistService,
  deleteWishlistService,
  setWishlistService,
} from "../services";

function* getWishlistSaga() {
  let response = yield setWishlistService();
  yield put({
    type: RED_GET_WISHLIST,
    result: "Done",
    data: response,
  });
}

function* createWishlistSaga(data) {
  //executer
  let response = yield addWishlistService(data);
  yield put({
    type: RED_ADD_WISHLIST,
    result: "Done",
    data: response,
  });
}

function* deleteWishlistSaga(data) {
  yield deleteWishlistService(data);
  yield put({ type: RED_DELETE_WISHLIST, result: "Done", data: data.payload });
}

export default function* wishlistSaga() {
  //watcher
  yield takeEvery(ADD_WISHLIST, createWishlistSaga);
  yield takeEvery(GET_WISHLIST, getWishlistSaga);
  yield takeEvery(DELETE_WISHLIST, deleteWishlistSaga);
}

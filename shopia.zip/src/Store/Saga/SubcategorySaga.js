import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_SUBCATEGORY,
  DELETE_SUBCATEGORY,
  GET_SUBCATEGORY,
  RED_ADD_SUBCATEGORY,
  RED_DELETE_SUBCATEGORY,
  RED_GET_SUBCATEGORY,
  RED_UPDATE_SUBCATEGORY,
  UPDATE_SUBCATEGORY,
} from "../Constant";
import {
  addsubcategoryService,
  deleteSubcategoryService,
  setSubcategoryService,
  updateSubcategoryService,
} from "../services";

function* getSubcategorySaga() {
  let response = yield setSubcategoryService();
  yield put({
    type: RED_GET_SUBCATEGORY,
    result: "Done",
    data: response,
  });
}

function* createSubcategorySaga(data) {
  //executer
  let response = yield addsubcategoryService(data);
  yield put({
    type: RED_ADD_SUBCATEGORY,
    result: "Done",
    data: response,
  });
}

function* updateSubcategorySaga(data) {
  //executer
  yield updateSubcategoryService(data.payload);
  yield put({
    type: RED_UPDATE_SUBCATEGORY,
    result: "Done",
    data: data.payload,
  });
}

function* deleteSubcategorySaga(data) {
  yield deleteSubcategoryService(data);
  yield put({
    type: RED_DELETE_SUBCATEGORY,
    result: "Done",
    data: data.payload,
  });
}

export default function* subcategorySaga() {
  //watcher
  yield takeEvery(ADD_SUBCATEGORY, createSubcategorySaga);
  yield takeEvery(GET_SUBCATEGORY, getSubcategorySaga);
  yield takeEvery(UPDATE_SUBCATEGORY, updateSubcategorySaga);
  yield takeEvery(DELETE_SUBCATEGORY, deleteSubcategorySaga);
}

import { takeEvery, put } from "@redux-saga/core/effects";
import {
  ADD_CART,
  DELETE_CART,
  GET_CART,
  RED_ADD_CART,
  RED_DELETE_CART,
  RED_GET_CART,
  RED_UPDATE_CART,
  UPDATE_CART,
} from "../Constant";
import {
  addCartService,
  deleteCartService,
  setCartService,
  updateCartService,
} from "../services";

function* getCartSaga() {
  let response = yield setCartService();
  yield put({
    type: RED_GET_CART,
    result: "Done",
    data: response,
  });
}

function* createCartSaga(data) {
  //executer
  let response = yield addCartService(data);
  yield put({
    type: RED_ADD_CART,
    result: "Done",
    data: response,
  });
}

function* updateCartSaga(data) {
  //executer
  yield updateCartService(data.payload);
  yield put({
    type: RED_UPDATE_CART,
    result: "Done",
    data: data.payload,
  });
}

function* deleteCartSaga(data) {
  yield deleteCartService(data);
  yield put({ type: RED_DELETE_CART, result: "Done", data: data.payload });
}

export default function* cartSaga() {
  //watcher
  yield takeEvery(ADD_CART, createCartSaga);
  yield takeEvery(GET_CART, getCartSaga);
  yield takeEvery(UPDATE_CART, updateCartSaga);
  yield takeEvery(DELETE_CART, deleteCartSaga);
}

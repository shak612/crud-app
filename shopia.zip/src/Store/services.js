//Maincategory Services
export async function addmaincategoryService(data) {
  let response = await fetch("/maincategory", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setMaincategoryService() {
  let response = await fetch("/maincategory");
  return await response.json();
}

export async function deleteMaincategoryService(data) {
  let response = await fetch("/maincategory/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateMaincategoryService(data) {
  let response = await fetch("/maincategory/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

//Subcategory Services
export async function addsubcategoryService(data) {
  let response = await fetch("/subcategory", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setSubcategoryService() {
  let response = await fetch("/subcategory");
  return await response.json();
}

export async function deleteSubcategoryService(data) {
  let response = await fetch("/subcategory/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateSubcategoryService(data) {
  let response = await fetch("/subcategory/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

//Brand Services
export async function addbrandService(data) {
  let response = await fetch("/brand", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setBrandService() {
  let response = await fetch("/brand");
  return await response.json();
}

export async function deleteBrandService(data) {
  let response = await fetch("/brand/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateBrandService(data) {
  let response = await fetch("/brand/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

//Product Services
export async function addproductService(data) {
  let response = await fetch("/product", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setProductService() {
  let response = await fetch("/product");
  return await response.json();
}

export async function deleteProductService(data) {
  let response = await fetch("/product/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateProductService(data) {
  let response = await fetch("/product/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

//User Services
export async function addUserService(data) {
  let response = await fetch("/user", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setUserService() {
  let response = await fetch("/user");
  return await response.json();
}

export async function setSingleUserService(data) {
  let response = await fetch("/user/" + data.id);
  return await response.json();
}

export async function deleteUserService(data) {
  let response = await fetch("/user/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateUserService(data) {
  let response = await fetch("/user/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

//Cart Services
export async function addCartService(data) {
  let response = await fetch("/cart", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setCartService() {
  let response = await fetch("/cart");
  return await response.json();
}

export async function deleteCartService(data) {
  let response = await fetch("/cart/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateCartService(data) {
  let response = await fetch("/cart/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

//Wishlist Services
export async function addWishlistService(data) {
  let response = await fetch("/wishlist", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setWishlistService() {
  let response = await fetch("/wishlist");
  return await response.json();
}

export async function deleteWishlistService(data) {
  let response = await fetch("/wishlist/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

//Checkout Services
export async function addCheckoutService(data) {
  let response = await fetch("/checkout", {
    method: "post",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data.payload),
  });
  return await response.json();
}

export async function setCheckoutService() {
  let response = await fetch("/checkout");
  return await response.json();
}

export async function deleteCheckoutService(data) {
  let response = await fetch("/checkout/" + data.payload.id, {
    method: "delete",
    headers: {
      "content-type": "application/json",
    },
  });
  return await response.json();
}

export async function updateCheckoutService(data) {
  let response = await fetch("/checkout/" + data.id, {
    method: "put",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return await response.json();
}

// constants for maincategory
export const ADD_MAINCATEGORY = "ADD_MAINCATEGORY";
export const RED_ADD_MAINCATEGORY = "RED_ADD_MAINCATEGORY";
export const GET_MAINCATEGORY = "GET_MAINCATEGORY";
export const RED_GET_MAINCATEGORY = "RED_GET_MAINCATEGORY";
export const DELETE_MAINCATEGORY = "DELETE_MAINCATEGORY";
export const RED_DELETE_MAINCATEGORY = "RED_DELETE_MAINCATEGORY";
export const UPDATE_MAINCATEGORY = "UPDATE_MAINCATEGORY";
export const RED_UPDATE_MAINCATEGORY = "RED_UPDATE_MAINCATEGORY";

// constants for subcategory
export const ADD_SUBCATEGORY = "ADD_SUBCATEGORY";
export const RED_ADD_SUBCATEGORY = "RED_ADD_SUBCATEGORY";
export const GET_SUBCATEGORY = "GET_SUBCATEGORY";
export const RED_GET_SUBCATEGORY = "RED_GET_SUBCATEGORY";
export const DELETE_SUBCATEGORY = "DELETE_SUBCATEGORY";
export const RED_DELETE_SUBCATEGORY = "RED_DELETE_SUBCATEGORY";
export const UPDATE_SUBCATEGORY = "UPDATE_SUBCATEGORY";
export const RED_UPDATE_SUBCATEGORY = "RED_UPDATE_SUBCATEGORY";

// constants for brand
export const ADD_BRAND = "ADD_BRAND";
export const RED_ADD_BRAND = "RED_ADD_BRAND";
export const GET_BRAND = "GET_BRAND";
export const RED_GET_BRAND = "RED_GET_BRAND";
export const DELETE_BRAND = "DELETE_BRAND";
export const RED_DELETE_BRAND = "RED_DELETE_BRAND";
export const UPDATE_BRAND = "UPDATE_BRAND";
export const RED_UPDATE_BRAND = "RED_UPDATE_BRAND";

// constants for product
export const ADD_PRODUCT = "ADD_PRODUCT";
export const RED_ADD_PRODUCT = "RED_ADD_PRODUCT";
export const GET_PRODUCT = "GET_PRODUCT";
export const RED_GET_PRODUCT = "RED_GET_PRODUCT";
export const DELETE_PRODUCT = "DELETE_PRODUCT";
export const RED_DELETE_PRODUCT = "RED_DELETE_PRODUCT";
export const UPDATE_PRODUCT = "UPDATE_PRODUCT";
export const RED_UPDATE_PRODUCT = "RED_UPDATE_PRODUCT";

// constants for user
export const REGISTER_USER = "REGISTER_USER";
export const RED_REGISTER_USER = "RED_REGISTER_USER";
export const GET_USER = "GET_USER";
export const RED_GET_USER = "RED_GET_USER";
export const GET_SINGLE_USER = "GET_SINGLE_USER";
export const RED_GET_SINGLE_USER = "RED_GET_SINGLE_USER";
export const DELETE_USER = "DELETE_USER";
export const RED_DELETE_USER = "RED_DELETE_USER";
export const UPDATE_USER = "UPDATE_USER";
export const RED_UPDATE_USER = "RED_UPDATE_USER";
export const LOGIN = "LOGIN";
export const RED_LOGIN = "RED_LOGIN";
export const LOGOUT_USER = "LOGOUT_USER";
export const RED_LOGOUT_USER = "RED_LOGOUT_USER";
export const LOGOUTALL_USER = "LOGOUTALL_USER";
export const RED_LOGOUTALL_USER = "RED_LOGOUTALL_USER";

// constants for cart
export const ADD_CART = "ADD_CART";
export const RED_ADD_CART = "RED_ADD_CART";
export const GET_CART = "GET_CART";
export const RED_GET_CART = "RED_GET_CART";
export const DELETE_CART = "DELETE_CART";
export const RED_DELETE_CART = "RED_DELETE_CART";
export const UPDATE_CART = "UPDATE_CART";
export const RED_UPDATE_CART = "RED_UPDATE_CART";

// constants for wishlist
export const ADD_WISHLIST = "ADD_WISHLIST";
export const RED_ADD_WISHLIST = "RED_ADD_WISHLIST";
export const GET_WISHLIST = "GET_WISHLIST";
export const RED_GET_WISHLIST = "RED_GET_WISHLIST";
export const DELETE_WISHLIST = "DELETE_WISHLIST";
export const RED_DELETE_WISHLIST = "RED_DELETE_WISHLIST";
export const UPDATE_WISHLIST = "UPDATE_WISHLIST";
export const RED_UPDATE_WISHLIST = "RED_UPDATE_WISHLIST";

// constants for checkout
export const ADD_CHECKOUT = "ADD_CHECKOUT";
export const RED_ADD_CHECKOUT = "RED_ADD_CHECKOUT";
export const GET_CHECKOUT = "GET_CHECKOUT";
export const RED_GET_CHECKOUT = "RED_GET_CHECKOUT";
export const DELETE_CHECKOUT = "DELETE_CHECKOUT";
export const RED_DELETE_CHECKOUT = "RED_DELETE_CHECKOUT";
export const UPDATE_CHECKOUT = "UPDATE_CHECKOUT";
export const RED_UPDATE_CHECKOUT = "RED_UPDATE_CHECKOUT";

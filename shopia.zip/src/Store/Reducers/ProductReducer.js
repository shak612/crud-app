import {
  RED_ADD_PRODUCT,
  RED_DELETE_PRODUCT,
  RED_GET_PRODUCT,
  RED_UPDATE_PRODUCT,
} from "../Constant";

export default function ProductReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_PRODUCT:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_PRODUCT:
      return action.data;
    case RED_UPDATE_PRODUCT:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index].name = action.data.name;
      return state;
    case RED_DELETE_PRODUCT:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

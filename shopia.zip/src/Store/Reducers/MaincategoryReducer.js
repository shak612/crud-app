import {
  RED_ADD_MAINCATEGORY,
  RED_DELETE_MAINCATEGORY,
  RED_GET_MAINCATEGORY,
  RED_UPDATE_MAINCATEGORY,
} from "../Constant";

export default function MaincategoryReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_MAINCATEGORY:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_MAINCATEGORY:
      return action.data;
    case RED_UPDATE_MAINCATEGORY:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index].name = action.data.name;
      return state;
    case RED_DELETE_MAINCATEGORY:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

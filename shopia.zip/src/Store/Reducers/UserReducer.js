import {
  RED_REGISTER_USER,
  RED_DELETE_USER,
  RED_GET_USER,
  RED_UPDATE_USER,
  RED_GET_SINGLE_USER,
  RED_LOGIN,
} from "../Constant";

export default function UserReducer(state = [], action) {
  switch (action.type) {
    case RED_REGISTER_USER:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];

    case RED_GET_USER:
      return action.data;

    case RED_GET_SINGLE_USER:
      return action.data;

    case RED_LOGIN:
      if (action.result === "Done")
        return { result: "Done", data: action.data };
      else return { result: action.result, data: [] };

    case RED_UPDATE_USER:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index] = action.data;
      return state;

    case RED_DELETE_USER:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;

    default:
      return state;
  }
}

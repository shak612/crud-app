import {
  RED_ADD_WISHLIST,
  RED_DELETE_WISHLIST,
  RED_GET_WISHLIST,
} from "../Constant";

export default function WishlistReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_WISHLIST:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_WISHLIST:
      return action.data;
    case RED_DELETE_WISHLIST:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

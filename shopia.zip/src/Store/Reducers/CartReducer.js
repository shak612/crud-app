import {
  RED_ADD_CART,
  RED_DELETE_CART,
  RED_GET_CART,
  RED_UPDATE_CART,
} from "../Constant";

export default function CartReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_CART:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_CART:
      return action.data;
    case RED_UPDATE_CART:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index].name = action.data.name;
      return state;
    case RED_DELETE_CART:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

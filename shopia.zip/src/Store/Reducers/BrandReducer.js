import {
  RED_ADD_BRAND,
  RED_DELETE_BRAND,
  RED_GET_BRAND,
  RED_UPDATE_BRAND,
} from "../Constant";

export default function BrandReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_BRAND:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_BRAND:
      return action.data;
    case RED_UPDATE_BRAND:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index].name = action.data.name;
      return state;
    case RED_DELETE_BRAND:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

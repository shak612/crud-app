import {
  RED_ADD_CHECKOUT,
  RED_DELETE_CHECKOUT,
  RED_GET_CHECKOUT,
  RED_UPDATE_CHECKOUT,
} from "../Constant";

export default function CheckoutReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_CHECKOUT:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_CHECKOUT:
      return action.data;
    case RED_UPDATE_CHECKOUT:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index].name = action.data.name;
      return state;
    case RED_DELETE_CHECKOUT:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

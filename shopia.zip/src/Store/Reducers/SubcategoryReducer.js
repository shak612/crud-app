import {
  DELETE_SUBCATEGORY,
  RED_ADD_SUBCATEGORY,
  RED_GET_SUBCATEGORY,
  RED_UPDATE_SUBCATEGORY,
} from "../Constant";

export default function SubcategoryReducer(state = [], action) {
  switch (action.type) {
    case RED_ADD_SUBCATEGORY:
      if (action.result === "Fail") {
        alert(action.msg);
        return state;
      } else return [...state, action.data];
    case RED_GET_SUBCATEGORY:
      return action.data;
    case RED_UPDATE_SUBCATEGORY:
      let index = state.findIndex((item) => item.id === Number(action.data.id));
      state[index].name = action.data.name;
      return state;
    case DELETE_SUBCATEGORY:
      let newState = state.filter((item) => item.id !== action.data.id);
      return newState;
    default:
      return state;
  }
}

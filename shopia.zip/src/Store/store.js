import { configureStore } from "@reduxjs/toolkit";
import createSagaMiddleware from "@redux-saga/core";
import RootSaga from "./Saga/RootSaga";
import RootReducer from "./Reducers/RootReducer";

const sagaMiddleware = createSagaMiddleware();
const store = configureStore({
  reducer: RootReducer,
  middleware: () => [sagaMiddleware],
});

export default store;
sagaMiddleware.run(RootSaga);
